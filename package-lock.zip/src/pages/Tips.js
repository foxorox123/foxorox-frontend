import React from "react";

function Tips() {
  return (
    <div className="main-container">
      <h1>Trading Tips</h1>
      <p>Here you will see all the market tips and analysis.</p>
    </div>
  );
}

export default Tips;